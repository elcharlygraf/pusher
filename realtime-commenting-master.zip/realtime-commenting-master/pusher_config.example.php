<?php
define('APP_ID', '');
define('APP_KEY', '');
define('APP_SECRET', '');
?>